package springalert.springalert.notification.dto;

import lombok.Data;

@Data
public class User {
    private int userId;
    private String firstName;
    private String lastName;
    private String preferredName;
    private String email;
}
