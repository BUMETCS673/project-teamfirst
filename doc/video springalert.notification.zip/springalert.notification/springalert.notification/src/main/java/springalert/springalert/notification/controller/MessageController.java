package springalert.springalert.notification.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springalert.springalert.notification.publisher.RabbitMQProducer;

@RestController
@RequestMapping("/api/v1")

public class MessageController {


    private RabbitMQProducer producer;
    public MessageController(RabbitMQProducer producer) {
        this.producer = producer;
    }

    //  http:8080/api/v1/publish?message=hello world
    @GetMapping("/publish")
    public ResponseEntity<String> sendMessage(@RequestParam("message") String message) {
        producer.sendMessage(message);
        return ResponseEntity.ok("Message sent to RabbitMQ");

    }


}
